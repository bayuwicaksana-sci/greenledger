import Routing from './Routing'
import Broadcasting from './Broadcasting'

const Illuminate = {
    Routing: Object.assign(Routing, Routing),
    Broadcasting: Object.assign(Broadcasting, Broadcasting),
}

export default Illuminate