import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\FiscalYearController::index
* @see app/Http/Controllers/FiscalYearController.php:25
* @route '/app/admin/fiscal-years'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/app/admin/fiscal-years',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FiscalYearController::index
* @see app/Http/Controllers/FiscalYearController.php:25
* @route '/app/admin/fiscal-years'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FiscalYearController::index
* @see app/Http/Controllers/FiscalYearController.php:25
* @route '/app/admin/fiscal-years'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FiscalYearController::index
* @see app/Http/Controllers/FiscalYearController.php:25
* @route '/app/admin/fiscal-years'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FiscalYearController::create
* @see app/Http/Controllers/FiscalYearController.php:49
* @route '/app/admin/fiscal-years/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/app/admin/fiscal-years/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FiscalYearController::create
* @see app/Http/Controllers/FiscalYearController.php:49
* @route '/app/admin/fiscal-years/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FiscalYearController::create
* @see app/Http/Controllers/FiscalYearController.php:49
* @route '/app/admin/fiscal-years/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FiscalYearController::create
* @see app/Http/Controllers/FiscalYearController.php:49
* @route '/app/admin/fiscal-years/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FiscalYearController::store
* @see app/Http/Controllers/FiscalYearController.php:57
* @route '/app/admin/fiscal-years'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/app/admin/fiscal-years',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FiscalYearController::store
* @see app/Http/Controllers/FiscalYearController.php:57
* @route '/app/admin/fiscal-years'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FiscalYearController::store
* @see app/Http/Controllers/FiscalYearController.php:57
* @route '/app/admin/fiscal-years'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FiscalYearController::show
* @see app/Http/Controllers/FiscalYearController.php:69
* @route '/app/admin/fiscal-years/{fiscal_year}'
*/
export const show = (args: { fiscal_year: string | number } | [fiscal_year: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/app/admin/fiscal-years/{fiscal_year}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FiscalYearController::show
* @see app/Http/Controllers/FiscalYearController.php:69
* @route '/app/admin/fiscal-years/{fiscal_year}'
*/
show.url = (args: { fiscal_year: string | number } | [fiscal_year: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fiscal_year: args }
    }

    if (Array.isArray(args)) {
        args = {
            fiscal_year: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        fiscal_year: args.fiscal_year,
    }

    return show.definition.url
            .replace('{fiscal_year}', parsedArgs.fiscal_year.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FiscalYearController::show
* @see app/Http/Controllers/FiscalYearController.php:69
* @route '/app/admin/fiscal-years/{fiscal_year}'
*/
show.get = (args: { fiscal_year: string | number } | [fiscal_year: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FiscalYearController::show
* @see app/Http/Controllers/FiscalYearController.php:69
* @route '/app/admin/fiscal-years/{fiscal_year}'
*/
show.head = (args: { fiscal_year: string | number } | [fiscal_year: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FiscalYearController::edit
* @see app/Http/Controllers/FiscalYearController.php:101
* @route '/app/admin/fiscal-years/{fiscal_year}/edit'
*/
export const edit = (args: { fiscal_year: string | number } | [fiscal_year: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/app/admin/fiscal-years/{fiscal_year}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FiscalYearController::edit
* @see app/Http/Controllers/FiscalYearController.php:101
* @route '/app/admin/fiscal-years/{fiscal_year}/edit'
*/
edit.url = (args: { fiscal_year: string | number } | [fiscal_year: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fiscal_year: args }
    }

    if (Array.isArray(args)) {
        args = {
            fiscal_year: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        fiscal_year: args.fiscal_year,
    }

    return edit.definition.url
            .replace('{fiscal_year}', parsedArgs.fiscal_year.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FiscalYearController::edit
* @see app/Http/Controllers/FiscalYearController.php:101
* @route '/app/admin/fiscal-years/{fiscal_year}/edit'
*/
edit.get = (args: { fiscal_year: string | number } | [fiscal_year: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FiscalYearController::edit
* @see app/Http/Controllers/FiscalYearController.php:101
* @route '/app/admin/fiscal-years/{fiscal_year}/edit'
*/
edit.head = (args: { fiscal_year: string | number } | [fiscal_year: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FiscalYearController::update
* @see app/Http/Controllers/FiscalYearController.php:113
* @route '/app/admin/fiscal-years/{fiscal_year}'
*/
export const update = (args: { fiscal_year: string | number } | [fiscal_year: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/app/admin/fiscal-years/{fiscal_year}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\FiscalYearController::update
* @see app/Http/Controllers/FiscalYearController.php:113
* @route '/app/admin/fiscal-years/{fiscal_year}'
*/
update.url = (args: { fiscal_year: string | number } | [fiscal_year: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fiscal_year: args }
    }

    if (Array.isArray(args)) {
        args = {
            fiscal_year: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        fiscal_year: args.fiscal_year,
    }

    return update.definition.url
            .replace('{fiscal_year}', parsedArgs.fiscal_year.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FiscalYearController::update
* @see app/Http/Controllers/FiscalYearController.php:113
* @route '/app/admin/fiscal-years/{fiscal_year}'
*/
update.put = (args: { fiscal_year: string | number } | [fiscal_year: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\FiscalYearController::update
* @see app/Http/Controllers/FiscalYearController.php:113
* @route '/app/admin/fiscal-years/{fiscal_year}'
*/
update.patch = (args: { fiscal_year: string | number } | [fiscal_year: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\FiscalYearController::destroy
* @see app/Http/Controllers/FiscalYearController.php:127
* @route '/app/admin/fiscal-years/{fiscal_year}'
*/
export const destroy = (args: { fiscal_year: string | number } | [fiscal_year: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/app/admin/fiscal-years/{fiscal_year}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\FiscalYearController::destroy
* @see app/Http/Controllers/FiscalYearController.php:127
* @route '/app/admin/fiscal-years/{fiscal_year}'
*/
destroy.url = (args: { fiscal_year: string | number } | [fiscal_year: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fiscal_year: args }
    }

    if (Array.isArray(args)) {
        args = {
            fiscal_year: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        fiscal_year: args.fiscal_year,
    }

    return destroy.definition.url
            .replace('{fiscal_year}', parsedArgs.fiscal_year.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FiscalYearController::destroy
* @see app/Http/Controllers/FiscalYearController.php:127
* @route '/app/admin/fiscal-years/{fiscal_year}'
*/
destroy.delete = (args: { fiscal_year: string | number } | [fiscal_year: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\FiscalYearController::close
* @see app/Http/Controllers/FiscalYearController.php:161
* @route '/app/admin/fiscal-years/{fiscalYear}/close'
*/
export const close = (args: { fiscalYear: number | { id: number } } | [fiscalYear: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: close.url(args, options),
    method: 'post',
})

close.definition = {
    methods: ["post"],
    url: '/app/admin/fiscal-years/{fiscalYear}/close',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FiscalYearController::close
* @see app/Http/Controllers/FiscalYearController.php:161
* @route '/app/admin/fiscal-years/{fiscalYear}/close'
*/
close.url = (args: { fiscalYear: number | { id: number } } | [fiscalYear: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fiscalYear: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { fiscalYear: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            fiscalYear: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        fiscalYear: typeof args.fiscalYear === 'object'
        ? args.fiscalYear.id
        : args.fiscalYear,
    }

    return close.definition.url
            .replace('{fiscalYear}', parsedArgs.fiscalYear.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FiscalYearController::close
* @see app/Http/Controllers/FiscalYearController.php:161
* @route '/app/admin/fiscal-years/{fiscalYear}/close'
*/
close.post = (args: { fiscalYear: number | { id: number } } | [fiscalYear: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: close.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FiscalYearController::reopen
* @see app/Http/Controllers/FiscalYearController.php:178
* @route '/app/admin/fiscal-years/{fiscalYear}/reopen'
*/
export const reopen = (args: { fiscalYear: number | { id: number } } | [fiscalYear: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reopen.url(args, options),
    method: 'post',
})

reopen.definition = {
    methods: ["post"],
    url: '/app/admin/fiscal-years/{fiscalYear}/reopen',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FiscalYearController::reopen
* @see app/Http/Controllers/FiscalYearController.php:178
* @route '/app/admin/fiscal-years/{fiscalYear}/reopen'
*/
reopen.url = (args: { fiscalYear: number | { id: number } } | [fiscalYear: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fiscalYear: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { fiscalYear: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            fiscalYear: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        fiscalYear: typeof args.fiscalYear === 'object'
        ? args.fiscalYear.id
        : args.fiscalYear,
    }

    return reopen.definition.url
            .replace('{fiscalYear}', parsedArgs.fiscalYear.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FiscalYearController::reopen
* @see app/Http/Controllers/FiscalYearController.php:178
* @route '/app/admin/fiscal-years/{fiscalYear}/reopen'
*/
reopen.post = (args: { fiscalYear: number | { id: number } } | [fiscalYear: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reopen.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FiscalYearController::downloadReport
* @see app/Http/Controllers/FiscalYearController.php:197
* @route '/app/admin/fiscal-years/{fiscalYear}/download-report'
*/
export const downloadReport = (args: { fiscalYear: number | { id: number } } | [fiscalYear: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadReport.url(args, options),
    method: 'get',
})

downloadReport.definition = {
    methods: ["get","head"],
    url: '/app/admin/fiscal-years/{fiscalYear}/download-report',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FiscalYearController::downloadReport
* @see app/Http/Controllers/FiscalYearController.php:197
* @route '/app/admin/fiscal-years/{fiscalYear}/download-report'
*/
downloadReport.url = (args: { fiscalYear: number | { id: number } } | [fiscalYear: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fiscalYear: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { fiscalYear: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            fiscalYear: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        fiscalYear: typeof args.fiscalYear === 'object'
        ? args.fiscalYear.id
        : args.fiscalYear,
    }

    return downloadReport.definition.url
            .replace('{fiscalYear}', parsedArgs.fiscalYear.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FiscalYearController::downloadReport
* @see app/Http/Controllers/FiscalYearController.php:197
* @route '/app/admin/fiscal-years/{fiscalYear}/download-report'
*/
downloadReport.get = (args: { fiscalYear: number | { id: number } } | [fiscalYear: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadReport.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FiscalYearController::downloadReport
* @see app/Http/Controllers/FiscalYearController.php:197
* @route '/app/admin/fiscal-years/{fiscalYear}/download-report'
*/
downloadReport.head = (args: { fiscalYear: number | { id: number } } | [fiscalYear: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadReport.url(args, options),
    method: 'head',
})

const FiscalYearController = { index, create, store, show, edit, update, destroy, close, reopen, downloadReport }

export default FiscalYearController