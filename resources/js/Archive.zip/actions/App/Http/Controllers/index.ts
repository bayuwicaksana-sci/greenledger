import AcceptInvitationController from './AcceptInvitationController'
import SiteController from './SiteController'
import RoleController from './RoleController'
import UserController from './UserController'
import UserAccessLogController from './UserAccessLogController'
import DashboardController from './DashboardController'
import Settings from './Settings'

const Controllers = {
    AcceptInvitationController: Object.assign(AcceptInvitationController, AcceptInvitationController),
    SiteController: Object.assign(SiteController, SiteController),
    RoleController: Object.assign(RoleController, RoleController),
    UserController: Object.assign(UserController, UserController),
    UserAccessLogController: Object.assign(UserAccessLogController, UserAccessLogController),
    DashboardController: Object.assign(DashboardController, DashboardController),
    Settings: Object.assign(Settings, Settings),
}

export default Controllers