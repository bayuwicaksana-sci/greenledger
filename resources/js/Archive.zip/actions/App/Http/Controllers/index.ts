import AcceptInvitationController from './AcceptInvitationController'
import SiteController from './SiteController'
import RoleController from './RoleController'
import UserAccessLogController from './UserAccessLogController'
import UserController from './UserController'
import MainDashboardController from './MainDashboardController'
import CoaAccountController from './CoaAccountController'
import CoaAccountImportController from './CoaAccountImportController'
import CoaAccountTemplateController from './CoaAccountTemplateController'
import ApprovalWorkflowController from './ApprovalWorkflowController'
import FiscalYearController from './FiscalYearController'
import NotificationController from './NotificationController'
import DashboardController from './DashboardController'
import ProgramController from './ProgramController'
import RevenueController from './RevenueController'
import HistoricalReportController from './HistoricalReportController'
import ApprovalInstanceController from './ApprovalInstanceController'
import Settings from './Settings'

const Controllers = {
    AcceptInvitationController: Object.assign(AcceptInvitationController, AcceptInvitationController),
    SiteController: Object.assign(SiteController, SiteController),
    RoleController: Object.assign(RoleController, RoleController),
    UserAccessLogController: Object.assign(UserAccessLogController, UserAccessLogController),
    UserController: Object.assign(UserController, UserController),
    MainDashboardController: Object.assign(MainDashboardController, MainDashboardController),
    CoaAccountController: Object.assign(CoaAccountController, CoaAccountController),
    CoaAccountImportController: Object.assign(CoaAccountImportController, CoaAccountImportController),
    CoaAccountTemplateController: Object.assign(CoaAccountTemplateController, CoaAccountTemplateController),
    ApprovalWorkflowController: Object.assign(ApprovalWorkflowController, ApprovalWorkflowController),
    FiscalYearController: Object.assign(FiscalYearController, FiscalYearController),
    NotificationController: Object.assign(NotificationController, NotificationController),
    DashboardController: Object.assign(DashboardController, DashboardController),
    ProgramController: Object.assign(ProgramController, ProgramController),
    RevenueController: Object.assign(RevenueController, RevenueController),
    HistoricalReportController: Object.assign(HistoricalReportController, HistoricalReportController),
    ApprovalInstanceController: Object.assign(ApprovalInstanceController, ApprovalInstanceController),
    Settings: Object.assign(Settings, Settings),
}

export default Controllers