import AcceptInvitationController from './AcceptInvitationController'
import Api from './Api'
import SiteController from './SiteController'
import RoleController from './RoleController'
import UserAccessLogController from './UserAccessLogController'
import UserController from './UserController'
import CoaAccountController from './CoaAccountController'
import CoaAccountImportController from './CoaAccountImportController'
import CoaAccountTemplateController from './CoaAccountTemplateController'
import ApprovalWorkflowController from './ApprovalWorkflowController'
import DashboardController from './DashboardController'
import ProgramController from './ProgramController'
import ApprovalInstanceController from './ApprovalInstanceController'
import Settings from './Settings'

const Controllers = {
    AcceptInvitationController: Object.assign(AcceptInvitationController, AcceptInvitationController),
    Api: Object.assign(Api, Api),
    SiteController: Object.assign(SiteController, SiteController),
    RoleController: Object.assign(RoleController, RoleController),
    UserAccessLogController: Object.assign(UserAccessLogController, UserAccessLogController),
    UserController: Object.assign(UserController, UserController),
    CoaAccountController: Object.assign(CoaAccountController, CoaAccountController),
    CoaAccountImportController: Object.assign(CoaAccountImportController, CoaAccountImportController),
    CoaAccountTemplateController: Object.assign(CoaAccountTemplateController, CoaAccountTemplateController),
    ApprovalWorkflowController: Object.assign(ApprovalWorkflowController, ApprovalWorkflowController),
    DashboardController: Object.assign(DashboardController, DashboardController),
    ProgramController: Object.assign(ProgramController, ProgramController),
    ApprovalInstanceController: Object.assign(ApprovalInstanceController, ApprovalInstanceController),
    Settings: Object.assign(Settings, Settings),
}

export default Controllers