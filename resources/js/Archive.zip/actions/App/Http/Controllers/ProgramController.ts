import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ProgramController::myPrograms
* @see app/Http/Controllers/ProgramController.php:508
* @route '/app/site/{site}/programs/my'
*/
export const myPrograms = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: myPrograms.url(args, options),
    method: 'get',
})

myPrograms.definition = {
    methods: ["get","head"],
    url: '/app/site/{site}/programs/my',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProgramController::myPrograms
* @see app/Http/Controllers/ProgramController.php:508
* @route '/app/site/{site}/programs/my'
*/
myPrograms.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return myPrograms.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProgramController::myPrograms
* @see app/Http/Controllers/ProgramController.php:508
* @route '/app/site/{site}/programs/my'
*/
myPrograms.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: myPrograms.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProgramController::myPrograms
* @see app/Http/Controllers/ProgramController.php:508
* @route '/app/site/{site}/programs/my'
*/
myPrograms.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: myPrograms.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProgramController::index
* @see app/Http/Controllers/ProgramController.php:26
* @route '/app/site/{site}/programs'
*/
export const index = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/app/site/{site}/programs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProgramController::index
* @see app/Http/Controllers/ProgramController.php:26
* @route '/app/site/{site}/programs'
*/
index.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return index.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProgramController::index
* @see app/Http/Controllers/ProgramController.php:26
* @route '/app/site/{site}/programs'
*/
index.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProgramController::index
* @see app/Http/Controllers/ProgramController.php:26
* @route '/app/site/{site}/programs'
*/
index.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProgramController::create
* @see app/Http/Controllers/ProgramController.php:66
* @route '/app/site/{site}/programs/create'
*/
export const create = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/app/site/{site}/programs/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProgramController::create
* @see app/Http/Controllers/ProgramController.php:66
* @route '/app/site/{site}/programs/create'
*/
create.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return create.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProgramController::create
* @see app/Http/Controllers/ProgramController.php:66
* @route '/app/site/{site}/programs/create'
*/
create.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProgramController::create
* @see app/Http/Controllers/ProgramController.php:66
* @route '/app/site/{site}/programs/create'
*/
create.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProgramController::store
* @see app/Http/Controllers/ProgramController.php:108
* @route '/app/site/{site}/programs'
*/
export const store = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/app/site/{site}/programs',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProgramController::store
* @see app/Http/Controllers/ProgramController.php:108
* @route '/app/site/{site}/programs'
*/
store.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return store.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProgramController::store
* @see app/Http/Controllers/ProgramController.php:108
* @route '/app/site/{site}/programs'
*/
store.post = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ProgramController::edit
* @see app/Http/Controllers/ProgramController.php:242
* @route '/app/site/{site}/programs/{program}/edit'
*/
export const edit = (args: { site: string | { site_code: string }, program: number | { id: number } } | [site: string | { site_code: string }, program: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/app/site/{site}/programs/{program}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProgramController::edit
* @see app/Http/Controllers/ProgramController.php:242
* @route '/app/site/{site}/programs/{program}/edit'
*/
edit.url = (args: { site: string | { site_code: string }, program: number | { id: number } } | [site: string | { site_code: string }, program: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            site: args[0],
            program: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
        program: typeof args.program === 'object'
        ? args.program.id
        : args.program,
    }

    return edit.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace('{program}', parsedArgs.program.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProgramController::edit
* @see app/Http/Controllers/ProgramController.php:242
* @route '/app/site/{site}/programs/{program}/edit'
*/
edit.get = (args: { site: string | { site_code: string }, program: number | { id: number } } | [site: string | { site_code: string }, program: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProgramController::edit
* @see app/Http/Controllers/ProgramController.php:242
* @route '/app/site/{site}/programs/{program}/edit'
*/
edit.head = (args: { site: string | { site_code: string }, program: number | { id: number } } | [site: string | { site_code: string }, program: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProgramController::update
* @see app/Http/Controllers/ProgramController.php:325
* @route '/app/site/{site}/programs/{program}'
*/
export const update = (args: { site: string | { site_code: string }, program: number | { id: number } } | [site: string | { site_code: string }, program: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/app/site/{site}/programs/{program}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ProgramController::update
* @see app/Http/Controllers/ProgramController.php:325
* @route '/app/site/{site}/programs/{program}'
*/
update.url = (args: { site: string | { site_code: string }, program: number | { id: number } } | [site: string | { site_code: string }, program: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            site: args[0],
            program: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
        program: typeof args.program === 'object'
        ? args.program.id
        : args.program,
    }

    return update.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace('{program}', parsedArgs.program.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProgramController::update
* @see app/Http/Controllers/ProgramController.php:325
* @route '/app/site/{site}/programs/{program}'
*/
update.put = (args: { site: string | { site_code: string }, program: number | { id: number } } | [site: string | { site_code: string }, program: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\ProgramController::destroy
* @see app/Http/Controllers/ProgramController.php:492
* @route '/app/site/{site}/programs/{program}'
*/
export const destroy = (args: { site: string | { site_code: string }, program: number | { id: number } } | [site: string | { site_code: string }, program: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/app/site/{site}/programs/{program}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ProgramController::destroy
* @see app/Http/Controllers/ProgramController.php:492
* @route '/app/site/{site}/programs/{program}'
*/
destroy.url = (args: { site: string | { site_code: string }, program: number | { id: number } } | [site: string | { site_code: string }, program: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            site: args[0],
            program: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
        program: typeof args.program === 'object'
        ? args.program.id
        : args.program,
    }

    return destroy.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace('{program}', parsedArgs.program.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProgramController::destroy
* @see app/Http/Controllers/ProgramController.php:492
* @route '/app/site/{site}/programs/{program}'
*/
destroy.delete = (args: { site: string | { site_code: string }, program: number | { id: number } } | [site: string | { site_code: string }, program: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\ProgramController::archived
* @see app/Http/Controllers/ProgramController.php:540
* @route '/app/site/{site}/programs/archived'
*/
export const archived = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: archived.url(args, options),
    method: 'get',
})

archived.definition = {
    methods: ["get","head"],
    url: '/app/site/{site}/programs/archived',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProgramController::archived
* @see app/Http/Controllers/ProgramController.php:540
* @route '/app/site/{site}/programs/archived'
*/
archived.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return archived.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProgramController::archived
* @see app/Http/Controllers/ProgramController.php:540
* @route '/app/site/{site}/programs/archived'
*/
archived.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: archived.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProgramController::archived
* @see app/Http/Controllers/ProgramController.php:540
* @route '/app/site/{site}/programs/archived'
*/
archived.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: archived.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ProgramController::show
* @see app/Http/Controllers/ProgramController.php:221
* @route '/app/site/{site}/programs/{program}'
*/
export const show = (args: { site: string | { site_code: string }, program: number | { id: number } } | [site: string | { site_code: string }, program: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/app/site/{site}/programs/{program}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProgramController::show
* @see app/Http/Controllers/ProgramController.php:221
* @route '/app/site/{site}/programs/{program}'
*/
show.url = (args: { site: string | { site_code: string }, program: number | { id: number } } | [site: string | { site_code: string }, program: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            site: args[0],
            program: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
        program: typeof args.program === 'object'
        ? args.program.id
        : args.program,
    }

    return show.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace('{program}', parsedArgs.program.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProgramController::show
* @see app/Http/Controllers/ProgramController.php:221
* @route '/app/site/{site}/programs/{program}'
*/
show.get = (args: { site: string | { site_code: string }, program: number | { id: number } } | [site: string | { site_code: string }, program: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ProgramController::show
* @see app/Http/Controllers/ProgramController.php:221
* @route '/app/site/{site}/programs/{program}'
*/
show.head = (args: { site: string | { site_code: string }, program: number | { id: number } } | [site: string | { site_code: string }, program: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

const ProgramController = { myPrograms, index, create, store, edit, update, destroy, archived, show }

export default ProgramController