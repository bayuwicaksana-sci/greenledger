import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CoaAccountController::bulkStore
* @see app/Http/Controllers/CoaAccountController.php:145
* @route '/app/config/coa/bulk'
*/
export const bulkStore = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkStore.url(options),
    method: 'post',
})

bulkStore.definition = {
    methods: ["post"],
    url: '/app/config/coa/bulk',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CoaAccountController::bulkStore
* @see app/Http/Controllers/CoaAccountController.php:145
* @route '/app/config/coa/bulk'
*/
bulkStore.url = (options?: RouteQueryOptions) => {
    return bulkStore.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CoaAccountController::bulkStore
* @see app/Http/Controllers/CoaAccountController.php:145
* @route '/app/config/coa/bulk'
*/
bulkStore.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkStore.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CoaAccountController::nextCode
* @see app/Http/Controllers/CoaAccountController.php:383
* @route '/app/config/coa/next-code'
*/
export const nextCode = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: nextCode.url(options),
    method: 'get',
})

nextCode.definition = {
    methods: ["get","head"],
    url: '/app/config/coa/next-code',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CoaAccountController::nextCode
* @see app/Http/Controllers/CoaAccountController.php:383
* @route '/app/config/coa/next-code'
*/
nextCode.url = (options?: RouteQueryOptions) => {
    return nextCode.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CoaAccountController::nextCode
* @see app/Http/Controllers/CoaAccountController.php:383
* @route '/app/config/coa/next-code'
*/
nextCode.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: nextCode.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CoaAccountController::nextCode
* @see app/Http/Controllers/CoaAccountController.php:383
* @route '/app/config/coa/next-code'
*/
nextCode.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: nextCode.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CoaAccountController::index
* @see app/Http/Controllers/CoaAccountController.php:24
* @route '/app/config/coa'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/app/config/coa',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CoaAccountController::index
* @see app/Http/Controllers/CoaAccountController.php:24
* @route '/app/config/coa'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CoaAccountController::index
* @see app/Http/Controllers/CoaAccountController.php:24
* @route '/app/config/coa'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CoaAccountController::index
* @see app/Http/Controllers/CoaAccountController.php:24
* @route '/app/config/coa'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CoaAccountController::create
* @see app/Http/Controllers/CoaAccountController.php:85
* @route '/app/config/coa/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/app/config/coa/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CoaAccountController::create
* @see app/Http/Controllers/CoaAccountController.php:85
* @route '/app/config/coa/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CoaAccountController::create
* @see app/Http/Controllers/CoaAccountController.php:85
* @route '/app/config/coa/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CoaAccountController::create
* @see app/Http/Controllers/CoaAccountController.php:85
* @route '/app/config/coa/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CoaAccountController::store
* @see app/Http/Controllers/CoaAccountController.php:113
* @route '/app/config/coa'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/app/config/coa',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CoaAccountController::store
* @see app/Http/Controllers/CoaAccountController.php:113
* @route '/app/config/coa'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CoaAccountController::store
* @see app/Http/Controllers/CoaAccountController.php:113
* @route '/app/config/coa'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\CoaAccountController::show
* @see app/Http/Controllers/CoaAccountController.php:0
* @route '/app/config/coa/{coa}'
*/
export const show = (args: { coa: string | number } | [coa: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/app/config/coa/{coa}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CoaAccountController::show
* @see app/Http/Controllers/CoaAccountController.php:0
* @route '/app/config/coa/{coa}'
*/
show.url = (args: { coa: string | number } | [coa: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { coa: args }
    }

    if (Array.isArray(args)) {
        args = {
            coa: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        coa: args.coa,
    }

    return show.definition.url
            .replace('{coa}', parsedArgs.coa.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CoaAccountController::show
* @see app/Http/Controllers/CoaAccountController.php:0
* @route '/app/config/coa/{coa}'
*/
show.get = (args: { coa: string | number } | [coa: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CoaAccountController::show
* @see app/Http/Controllers/CoaAccountController.php:0
* @route '/app/config/coa/{coa}'
*/
show.head = (args: { coa: string | number } | [coa: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CoaAccountController::edit
* @see app/Http/Controllers/CoaAccountController.php:262
* @route '/app/config/coa/{coa}/edit'
*/
export const edit = (args: { coa: number | { id: number } } | [coa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/app/config/coa/{coa}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CoaAccountController::edit
* @see app/Http/Controllers/CoaAccountController.php:262
* @route '/app/config/coa/{coa}/edit'
*/
edit.url = (args: { coa: number | { id: number } } | [coa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { coa: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { coa: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            coa: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        coa: typeof args.coa === 'object'
        ? args.coa.id
        : args.coa,
    }

    return edit.definition.url
            .replace('{coa}', parsedArgs.coa.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CoaAccountController::edit
* @see app/Http/Controllers/CoaAccountController.php:262
* @route '/app/config/coa/{coa}/edit'
*/
edit.get = (args: { coa: number | { id: number } } | [coa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CoaAccountController::edit
* @see app/Http/Controllers/CoaAccountController.php:262
* @route '/app/config/coa/{coa}/edit'
*/
edit.head = (args: { coa: number | { id: number } } | [coa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CoaAccountController::update
* @see app/Http/Controllers/CoaAccountController.php:305
* @route '/app/config/coa/{coa}'
*/
export const update = (args: { coa: number | { id: number } } | [coa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/app/config/coa/{coa}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\CoaAccountController::update
* @see app/Http/Controllers/CoaAccountController.php:305
* @route '/app/config/coa/{coa}'
*/
update.url = (args: { coa: number | { id: number } } | [coa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { coa: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { coa: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            coa: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        coa: typeof args.coa === 'object'
        ? args.coa.id
        : args.coa,
    }

    return update.definition.url
            .replace('{coa}', parsedArgs.coa.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CoaAccountController::update
* @see app/Http/Controllers/CoaAccountController.php:305
* @route '/app/config/coa/{coa}'
*/
update.put = (args: { coa: number | { id: number } } | [coa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\CoaAccountController::update
* @see app/Http/Controllers/CoaAccountController.php:305
* @route '/app/config/coa/{coa}'
*/
update.patch = (args: { coa: number | { id: number } } | [coa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\CoaAccountController::destroy
* @see app/Http/Controllers/CoaAccountController.php:333
* @route '/app/config/coa/{coa}'
*/
export const destroy = (args: { coa: number | { id: number } } | [coa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/app/config/coa/{coa}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CoaAccountController::destroy
* @see app/Http/Controllers/CoaAccountController.php:333
* @route '/app/config/coa/{coa}'
*/
destroy.url = (args: { coa: number | { id: number } } | [coa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { coa: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { coa: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            coa: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        coa: typeof args.coa === 'object'
        ? args.coa.id
        : args.coa,
    }

    return destroy.definition.url
            .replace('{coa}', parsedArgs.coa.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CoaAccountController::destroy
* @see app/Http/Controllers/CoaAccountController.php:333
* @route '/app/config/coa/{coa}'
*/
destroy.delete = (args: { coa: number | { id: number } } | [coa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

const CoaAccountController = { bulkStore, nextCode, index, create, store, show, edit, update, destroy }

export default CoaAccountController