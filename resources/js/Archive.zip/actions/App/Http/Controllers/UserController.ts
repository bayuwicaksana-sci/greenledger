import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\UserController::index
* @see app/Http/Controllers/UserController.php:31
* @route '/api/users'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/users',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UserController::index
* @see app/Http/Controllers/UserController.php:31
* @route '/api/users'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::index
* @see app/Http/Controllers/UserController.php:31
* @route '/api/users'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::index
* @see app/Http/Controllers/UserController.php:31
* @route '/api/users'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\UserController::show
* @see app/Http/Controllers/UserController.php:100
* @route '/api/users/{user}'
*/
export const show = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/users/{user}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UserController::show
* @see app/Http/Controllers/UserController.php:100
* @route '/api/users/{user}'
*/
show.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { user: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            user: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        user: typeof args.user === 'object'
        ? args.user.id
        : args.user,
    }

    return show.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::show
* @see app/Http/Controllers/UserController.php:100
* @route '/api/users/{user}'
*/
show.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::show
* @see app/Http/Controllers/UserController.php:100
* @route '/api/users/{user}'
*/
show.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\UserController::invite
* @see app/Http/Controllers/UserController.php:114
* @route '/api/users/invite'
*/
export const invite = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: invite.url(options),
    method: 'post',
})

invite.definition = {
    methods: ["post"],
    url: '/api/users/invite',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UserController::invite
* @see app/Http/Controllers/UserController.php:114
* @route '/api/users/invite'
*/
invite.url = (options?: RouteQueryOptions) => {
    return invite.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::invite
* @see app/Http/Controllers/UserController.php:114
* @route '/api/users/invite'
*/
invite.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: invite.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UserController::bulkInvite
* @see app/Http/Controllers/UserController.php:338
* @route '/api/users/bulk-invite'
*/
export const bulkInvite = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkInvite.url(options),
    method: 'post',
})

bulkInvite.definition = {
    methods: ["post"],
    url: '/api/users/bulk-invite',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UserController::bulkInvite
* @see app/Http/Controllers/UserController.php:338
* @route '/api/users/bulk-invite'
*/
bulkInvite.url = (options?: RouteQueryOptions) => {
    return bulkInvite.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::bulkInvite
* @see app/Http/Controllers/UserController.php:338
* @route '/api/users/bulk-invite'
*/
bulkInvite.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkInvite.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UserController::invitations
* @see app/Http/Controllers/UserController.php:276
* @route '/api/users/`invitations`'
*/
export const invitations = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: invitations.url(options),
    method: 'get',
})

invitations.definition = {
    methods: ["get","head"],
    url: '/api/users/`invitations`',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UserController::invitations
* @see app/Http/Controllers/UserController.php:276
* @route '/api/users/`invitations`'
*/
invitations.url = (options?: RouteQueryOptions) => {
    return invitations.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::invitations
* @see app/Http/Controllers/UserController.php:276
* @route '/api/users/`invitations`'
*/
invitations.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: invitations.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\UserController::invitations
* @see app/Http/Controllers/UserController.php:276
* @route '/api/users/`invitations`'
*/
invitations.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: invitations.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\UserController::resendInvitation
* @see app/Http/Controllers/UserController.php:297
* @route '/api/users/invitations/{invitation}/resend'
*/
export const resendInvitation = (args: { invitation: number | { id: number } } | [invitation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resendInvitation.url(args, options),
    method: 'post',
})

resendInvitation.definition = {
    methods: ["post"],
    url: '/api/users/invitations/{invitation}/resend',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UserController::resendInvitation
* @see app/Http/Controllers/UserController.php:297
* @route '/api/users/invitations/{invitation}/resend'
*/
resendInvitation.url = (args: { invitation: number | { id: number } } | [invitation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invitation: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { invitation: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            invitation: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        invitation: typeof args.invitation === 'object'
        ? args.invitation.id
        : args.invitation,
    }

    return resendInvitation.definition.url
            .replace('{invitation}', parsedArgs.invitation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::resendInvitation
* @see app/Http/Controllers/UserController.php:297
* @route '/api/users/invitations/{invitation}/resend'
*/
resendInvitation.post = (args: { invitation: number | { id: number } } | [invitation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resendInvitation.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UserController::cancelInvitation
* @see app/Http/Controllers/UserController.php:320
* @route '/api/users/invitations/{invitation}'
*/
export const cancelInvitation = (args: { invitation: number | { id: number } } | [invitation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: cancelInvitation.url(args, options),
    method: 'delete',
})

cancelInvitation.definition = {
    methods: ["delete"],
    url: '/api/users/invitations/{invitation}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\UserController::cancelInvitation
* @see app/Http/Controllers/UserController.php:320
* @route '/api/users/invitations/{invitation}'
*/
cancelInvitation.url = (args: { invitation: number | { id: number } } | [invitation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invitation: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { invitation: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            invitation: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        invitation: typeof args.invitation === 'object'
        ? args.invitation.id
        : args.invitation,
    }

    return cancelInvitation.definition.url
            .replace('{invitation}', parsedArgs.invitation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::cancelInvitation
* @see app/Http/Controllers/UserController.php:320
* @route '/api/users/invitations/{invitation}'
*/
cancelInvitation.delete = (args: { invitation: number | { id: number } } | [invitation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: cancelInvitation.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\UserController::update
* @see app/Http/Controllers/UserController.php:151
* @route '/api/users/{user}'
*/
export const update = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/users/{user}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\UserController::update
* @see app/Http/Controllers/UserController.php:151
* @route '/api/users/{user}'
*/
update.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { user: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            user: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        user: typeof args.user === 'object'
        ? args.user.id
        : args.user,
    }

    return update.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::update
* @see app/Http/Controllers/UserController.php:151
* @route '/api/users/{user}'
*/
update.put = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\UserController::toggleStatus
* @see app/Http/Controllers/UserController.php:170
* @route '/api/users/{user}/toggle-status'
*/
export const toggleStatus = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleStatus.url(args, options),
    method: 'post',
})

toggleStatus.definition = {
    methods: ["post"],
    url: '/api/users/{user}/toggle-status',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UserController::toggleStatus
* @see app/Http/Controllers/UserController.php:170
* @route '/api/users/{user}/toggle-status'
*/
toggleStatus.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { user: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            user: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        user: typeof args.user === 'object'
        ? args.user.id
        : args.user,
    }

    return toggleStatus.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::toggleStatus
* @see app/Http/Controllers/UserController.php:170
* @route '/api/users/{user}/toggle-status'
*/
toggleStatus.post = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleStatus.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UserController::bulkToggleStatus
* @see app/Http/Controllers/UserController.php:386
* @route '/api/users/bulk-toggle-status'
*/
export const bulkToggleStatus = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkToggleStatus.url(options),
    method: 'post',
})

bulkToggleStatus.definition = {
    methods: ["post"],
    url: '/api/users/bulk-toggle-status',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UserController::bulkToggleStatus
* @see app/Http/Controllers/UserController.php:386
* @route '/api/users/bulk-toggle-status'
*/
bulkToggleStatus.url = (options?: RouteQueryOptions) => {
    return bulkToggleStatus.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::bulkToggleStatus
* @see app/Http/Controllers/UserController.php:386
* @route '/api/users/bulk-toggle-status'
*/
bulkToggleStatus.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkToggleStatus.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UserController::assignRoles
* @see app/Http/Controllers/UserController.php:193
* @route '/api/users/{user}/roles'
*/
export const assignRoles = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: assignRoles.url(args, options),
    method: 'put',
})

assignRoles.definition = {
    methods: ["put"],
    url: '/api/users/{user}/roles',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\UserController::assignRoles
* @see app/Http/Controllers/UserController.php:193
* @route '/api/users/{user}/roles'
*/
assignRoles.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { user: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            user: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        user: typeof args.user === 'object'
        ? args.user.id
        : args.user,
    }

    return assignRoles.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::assignRoles
* @see app/Http/Controllers/UserController.php:193
* @route '/api/users/{user}/roles'
*/
assignRoles.put = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: assignRoles.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\UserController::bulkAssignRoles
* @see app/Http/Controllers/UserController.php:412
* @route '/api/users/bulk-assign-roles'
*/
export const bulkAssignRoles = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkAssignRoles.url(options),
    method: 'post',
})

bulkAssignRoles.definition = {
    methods: ["post"],
    url: '/api/users/bulk-assign-roles',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UserController::bulkAssignRoles
* @see app/Http/Controllers/UserController.php:412
* @route '/api/users/bulk-assign-roles'
*/
bulkAssignRoles.url = (options?: RouteQueryOptions) => {
    return bulkAssignRoles.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::bulkAssignRoles
* @see app/Http/Controllers/UserController.php:412
* @route '/api/users/bulk-assign-roles'
*/
bulkAssignRoles.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkAssignRoles.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UserController::assignSites
* @see app/Http/Controllers/UserController.php:212
* @route '/api/users/{user}/sites'
*/
export const assignSites = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: assignSites.url(args, options),
    method: 'put',
})

assignSites.definition = {
    methods: ["put"],
    url: '/api/users/{user}/sites',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\UserController::assignSites
* @see app/Http/Controllers/UserController.php:212
* @route '/api/users/{user}/sites'
*/
assignSites.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { user: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            user: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        user: typeof args.user === 'object'
        ? args.user.id
        : args.user,
    }

    return assignSites.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::assignSites
* @see app/Http/Controllers/UserController.php:212
* @route '/api/users/{user}/sites'
*/
assignSites.put = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: assignSites.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\UserController::resetPassword
* @see app/Http/Controllers/UserController.php:247
* @route '/api/users/{user}/reset-password'
*/
export const resetPassword = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetPassword.url(args, options),
    method: 'post',
})

resetPassword.definition = {
    methods: ["post"],
    url: '/api/users/{user}/reset-password',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UserController::resetPassword
* @see app/Http/Controllers/UserController.php:247
* @route '/api/users/{user}/reset-password'
*/
resetPassword.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { user: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            user: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        user: typeof args.user === 'object'
        ? args.user.id
        : args.user,
    }

    return resetPassword.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::resetPassword
* @see app/Http/Controllers/UserController.php:247
* @route '/api/users/{user}/reset-password'
*/
resetPassword.post = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetPassword.url(args, options),
    method: 'post',
})

const UserController = { index, show, invite, bulkInvite, invitations, resendInvitation, cancelInvitation, update, toggleStatus, bulkToggleStatus, assignRoles, bulkAssignRoles, assignSites, resetPassword }

export default UserController