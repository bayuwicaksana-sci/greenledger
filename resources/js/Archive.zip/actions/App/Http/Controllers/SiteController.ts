import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SiteController::apiIndex
* @see app/Http/Controllers/SiteController.php:90
* @route '/api/sites'
*/
export const apiIndex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: apiIndex.url(options),
    method: 'get',
})

apiIndex.definition = {
    methods: ["get","head"],
    url: '/api/sites',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SiteController::apiIndex
* @see app/Http/Controllers/SiteController.php:90
* @route '/api/sites'
*/
apiIndex.url = (options?: RouteQueryOptions) => {
    return apiIndex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteController::apiIndex
* @see app/Http/Controllers/SiteController.php:90
* @route '/api/sites'
*/
apiIndex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: apiIndex.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SiteController::apiIndex
* @see app/Http/Controllers/SiteController.php:90
* @route '/api/sites'
*/
apiIndex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: apiIndex.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SiteController::index
* @see app/Http/Controllers/SiteController.php:17
* @route '/app/research-stations'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/app/research-stations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SiteController::index
* @see app/Http/Controllers/SiteController.php:17
* @route '/app/research-stations'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteController::index
* @see app/Http/Controllers/SiteController.php:17
* @route '/app/research-stations'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SiteController::index
* @see app/Http/Controllers/SiteController.php:17
* @route '/app/research-stations'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SiteController::create
* @see app/Http/Controllers/SiteController.php:32
* @route '/app/research-stations/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/app/research-stations/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SiteController::create
* @see app/Http/Controllers/SiteController.php:32
* @route '/app/research-stations/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteController::create
* @see app/Http/Controllers/SiteController.php:32
* @route '/app/research-stations/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SiteController::create
* @see app/Http/Controllers/SiteController.php:32
* @route '/app/research-stations/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SiteController::store
* @see app/Http/Controllers/SiteController.php:40
* @route '/app/research-stations'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/app/research-stations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SiteController::store
* @see app/Http/Controllers/SiteController.php:40
* @route '/app/research-stations'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteController::store
* @see app/Http/Controllers/SiteController.php:40
* @route '/app/research-stations'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SiteController::suggestCode
* @see app/Http/Controllers/SiteController.php:52
* @route '/app/research-stations/suggest-code'
*/
export const suggestCode = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: suggestCode.url(options),
    method: 'get',
})

suggestCode.definition = {
    methods: ["get","head"],
    url: '/app/research-stations/suggest-code',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SiteController::suggestCode
* @see app/Http/Controllers/SiteController.php:52
* @route '/app/research-stations/suggest-code'
*/
suggestCode.url = (options?: RouteQueryOptions) => {
    return suggestCode.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteController::suggestCode
* @see app/Http/Controllers/SiteController.php:52
* @route '/app/research-stations/suggest-code'
*/
suggestCode.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: suggestCode.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SiteController::suggestCode
* @see app/Http/Controllers/SiteController.php:52
* @route '/app/research-stations/suggest-code'
*/
suggestCode.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: suggestCode.url(options),
    method: 'head',
})

const SiteController = { apiIndex, index, create, store, suggestCode }

export default SiteController