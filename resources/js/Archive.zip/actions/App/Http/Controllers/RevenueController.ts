import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\RevenueController::createHarvest
* @see app/Http/Controllers/RevenueController.php:17
* @route '/app/site/{site}/revenue/harvest/create'
*/
export const createHarvest = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createHarvest.url(args, options),
    method: 'get',
})

createHarvest.definition = {
    methods: ["get","head"],
    url: '/app/site/{site}/revenue/harvest/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RevenueController::createHarvest
* @see app/Http/Controllers/RevenueController.php:17
* @route '/app/site/{site}/revenue/harvest/create'
*/
createHarvest.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return createHarvest.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RevenueController::createHarvest
* @see app/Http/Controllers/RevenueController.php:17
* @route '/app/site/{site}/revenue/harvest/create'
*/
createHarvest.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createHarvest.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RevenueController::createHarvest
* @see app/Http/Controllers/RevenueController.php:17
* @route '/app/site/{site}/revenue/harvest/create'
*/
createHarvest.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: createHarvest.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\RevenueController::storeHarvest
* @see app/Http/Controllers/RevenueController.php:34
* @route '/app/site/{site}/revenue/harvest'
*/
export const storeHarvest = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeHarvest.url(args, options),
    method: 'post',
})

storeHarvest.definition = {
    methods: ["post"],
    url: '/app/site/{site}/revenue/harvest',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RevenueController::storeHarvest
* @see app/Http/Controllers/RevenueController.php:34
* @route '/app/site/{site}/revenue/harvest'
*/
storeHarvest.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return storeHarvest.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RevenueController::storeHarvest
* @see app/Http/Controllers/RevenueController.php:34
* @route '/app/site/{site}/revenue/harvest'
*/
storeHarvest.post = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeHarvest.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\RevenueController::createTesting
* @see app/Http/Controllers/RevenueController.php:63
* @route '/app/site/{site}/revenue/testing/create'
*/
export const createTesting = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createTesting.url(args, options),
    method: 'get',
})

createTesting.definition = {
    methods: ["get","head"],
    url: '/app/site/{site}/revenue/testing/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RevenueController::createTesting
* @see app/Http/Controllers/RevenueController.php:63
* @route '/app/site/{site}/revenue/testing/create'
*/
createTesting.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return createTesting.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RevenueController::createTesting
* @see app/Http/Controllers/RevenueController.php:63
* @route '/app/site/{site}/revenue/testing/create'
*/
createTesting.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createTesting.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\RevenueController::createTesting
* @see app/Http/Controllers/RevenueController.php:63
* @route '/app/site/{site}/revenue/testing/create'
*/
createTesting.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: createTesting.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\RevenueController::storeTesting
* @see app/Http/Controllers/RevenueController.php:71
* @route '/app/site/{site}/revenue/testing'
*/
export const storeTesting = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeTesting.url(args, options),
    method: 'post',
})

storeTesting.definition = {
    methods: ["post"],
    url: '/app/site/{site}/revenue/testing',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RevenueController::storeTesting
* @see app/Http/Controllers/RevenueController.php:71
* @route '/app/site/{site}/revenue/testing'
*/
storeTesting.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return storeTesting.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RevenueController::storeTesting
* @see app/Http/Controllers/RevenueController.php:71
* @route '/app/site/{site}/revenue/testing'
*/
storeTesting.post = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeTesting.url(args, options),
    method: 'post',
})

const RevenueController = { createHarvest, storeHarvest, createTesting, storeTesting }

export default RevenueController