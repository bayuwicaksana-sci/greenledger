import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\ApprovalActionController::process
* @see [unknown]:0
* @route '/api/approvals/instances/{approvalInstance}/actions'
*/
export const process = (args: { approvalInstance: string | number } | [approvalInstance: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: process.url(args, options),
    method: 'post',
})

process.definition = {
    methods: ["post"],
    url: '/api/approvals/instances/{approvalInstance}/actions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ApprovalActionController::process
* @see [unknown]:0
* @route '/api/approvals/instances/{approvalInstance}/actions'
*/
process.url = (args: { approvalInstance: string | number } | [approvalInstance: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { approvalInstance: args }
    }

    if (Array.isArray(args)) {
        args = {
            approvalInstance: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        approvalInstance: args.approvalInstance,
    }

    return process.definition.url
            .replace('{approvalInstance}', parsedArgs.approvalInstance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ApprovalActionController::process
* @see [unknown]:0
* @route '/api/approvals/instances/{approvalInstance}/actions'
*/
process.post = (args: { approvalInstance: string | number } | [approvalInstance: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: process.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\ApprovalActionController::history
* @see [unknown]:0
* @route '/api/approvals/instances/{approvalInstance}/history'
*/
export const history = (args: { approvalInstance: string | number } | [approvalInstance: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(args, options),
    method: 'get',
})

history.definition = {
    methods: ["get","head"],
    url: '/api/approvals/instances/{approvalInstance}/history',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ApprovalActionController::history
* @see [unknown]:0
* @route '/api/approvals/instances/{approvalInstance}/history'
*/
history.url = (args: { approvalInstance: string | number } | [approvalInstance: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { approvalInstance: args }
    }

    if (Array.isArray(args)) {
        args = {
            approvalInstance: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        approvalInstance: args.approvalInstance,
    }

    return history.definition.url
            .replace('{approvalInstance}', parsedArgs.approvalInstance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ApprovalActionController::history
* @see [unknown]:0
* @route '/api/approvals/instances/{approvalInstance}/history'
*/
history.get = (args: { approvalInstance: string | number } | [approvalInstance: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ApprovalActionController::history
* @see [unknown]:0
* @route '/api/approvals/instances/{approvalInstance}/history'
*/
history.head = (args: { approvalInstance: string | number } | [approvalInstance: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: history.url(args, options),
    method: 'head',
})

const ApprovalActionController = { process, history }

export default ApprovalActionController