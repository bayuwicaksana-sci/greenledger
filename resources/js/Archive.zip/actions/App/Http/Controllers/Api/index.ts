import ApprovalWorkflowController from './ApprovalWorkflowController'
import ApprovalInstanceController from './ApprovalInstanceController'
import ApprovalActionController from './ApprovalActionController'

const Api = {
    ApprovalWorkflowController: Object.assign(ApprovalWorkflowController, ApprovalWorkflowController),
    ApprovalInstanceController: Object.assign(ApprovalInstanceController, ApprovalInstanceController),
    ApprovalActionController: Object.assign(ApprovalActionController, ApprovalActionController),
}

export default Api