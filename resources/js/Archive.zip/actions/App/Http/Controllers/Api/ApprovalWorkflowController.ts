import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::index
* @see [unknown]:0
* @route '/api/approvals/workflows'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/approvals/workflows',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::index
* @see [unknown]:0
* @route '/api/approvals/workflows'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::index
* @see [unknown]:0
* @route '/api/approvals/workflows'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::index
* @see [unknown]:0
* @route '/api/approvals/workflows'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::show
* @see [unknown]:0
* @route '/api/approvals/workflows/{approvalWorkflow}'
*/
export const show = (args: { approvalWorkflow: string | number } | [approvalWorkflow: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/approvals/workflows/{approvalWorkflow}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::show
* @see [unknown]:0
* @route '/api/approvals/workflows/{approvalWorkflow}'
*/
show.url = (args: { approvalWorkflow: string | number } | [approvalWorkflow: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { approvalWorkflow: args }
    }

    if (Array.isArray(args)) {
        args = {
            approvalWorkflow: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        approvalWorkflow: args.approvalWorkflow,
    }

    return show.definition.url
            .replace('{approvalWorkflow}', parsedArgs.approvalWorkflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::show
* @see [unknown]:0
* @route '/api/approvals/workflows/{approvalWorkflow}'
*/
show.get = (args: { approvalWorkflow: string | number } | [approvalWorkflow: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::show
* @see [unknown]:0
* @route '/api/approvals/workflows/{approvalWorkflow}'
*/
show.head = (args: { approvalWorkflow: string | number } | [approvalWorkflow: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::store
* @see [unknown]:0
* @route '/api/approvals/workflows'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/approvals/workflows',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::store
* @see [unknown]:0
* @route '/api/approvals/workflows'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::store
* @see [unknown]:0
* @route '/api/approvals/workflows'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::update
* @see [unknown]:0
* @route '/api/approvals/workflows/{approvalWorkflow}'
*/
export const update = (args: { approvalWorkflow: string | number } | [approvalWorkflow: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/approvals/workflows/{approvalWorkflow}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::update
* @see [unknown]:0
* @route '/api/approvals/workflows/{approvalWorkflow}'
*/
update.url = (args: { approvalWorkflow: string | number } | [approvalWorkflow: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { approvalWorkflow: args }
    }

    if (Array.isArray(args)) {
        args = {
            approvalWorkflow: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        approvalWorkflow: args.approvalWorkflow,
    }

    return update.definition.url
            .replace('{approvalWorkflow}', parsedArgs.approvalWorkflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::update
* @see [unknown]:0
* @route '/api/approvals/workflows/{approvalWorkflow}'
*/
update.put = (args: { approvalWorkflow: string | number } | [approvalWorkflow: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::createVersion
* @see [unknown]:0
* @route '/api/approvals/workflows/{approvalWorkflow}/versions'
*/
export const createVersion = (args: { approvalWorkflow: string | number } | [approvalWorkflow: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: createVersion.url(args, options),
    method: 'post',
})

createVersion.definition = {
    methods: ["post"],
    url: '/api/approvals/workflows/{approvalWorkflow}/versions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::createVersion
* @see [unknown]:0
* @route '/api/approvals/workflows/{approvalWorkflow}/versions'
*/
createVersion.url = (args: { approvalWorkflow: string | number } | [approvalWorkflow: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { approvalWorkflow: args }
    }

    if (Array.isArray(args)) {
        args = {
            approvalWorkflow: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        approvalWorkflow: args.approvalWorkflow,
    }

    return createVersion.definition.url
            .replace('{approvalWorkflow}', parsedArgs.approvalWorkflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::createVersion
* @see [unknown]:0
* @route '/api/approvals/workflows/{approvalWorkflow}/versions'
*/
createVersion.post = (args: { approvalWorkflow: string | number } | [approvalWorkflow: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: createVersion.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::activateVersion
* @see [unknown]:0
* @route '/api/approvals/workflows/{approvalWorkflow}/versions/{versionId}/activate'
*/
export const activateVersion = (args: { approvalWorkflow: string | number, versionId: string | number } | [approvalWorkflow: string | number, versionId: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: activateVersion.url(args, options),
    method: 'post',
})

activateVersion.definition = {
    methods: ["post"],
    url: '/api/approvals/workflows/{approvalWorkflow}/versions/{versionId}/activate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::activateVersion
* @see [unknown]:0
* @route '/api/approvals/workflows/{approvalWorkflow}/versions/{versionId}/activate'
*/
activateVersion.url = (args: { approvalWorkflow: string | number, versionId: string | number } | [approvalWorkflow: string | number, versionId: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            approvalWorkflow: args[0],
            versionId: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        approvalWorkflow: args.approvalWorkflow,
        versionId: args.versionId,
    }

    return activateVersion.definition.url
            .replace('{approvalWorkflow}', parsedArgs.approvalWorkflow.toString())
            .replace('{versionId}', parsedArgs.versionId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::activateVersion
* @see [unknown]:0
* @route '/api/approvals/workflows/{approvalWorkflow}/versions/{versionId}/activate'
*/
activateVersion.post = (args: { approvalWorkflow: string | number, versionId: string | number } | [approvalWorkflow: string | number, versionId: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: activateVersion.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::deactivate
* @see [unknown]:0
* @route '/api/approvals/workflows/{approvalWorkflow}/deactivate'
*/
export const deactivate = (args: { approvalWorkflow: string | number } | [approvalWorkflow: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: deactivate.url(args, options),
    method: 'post',
})

deactivate.definition = {
    methods: ["post"],
    url: '/api/approvals/workflows/{approvalWorkflow}/deactivate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::deactivate
* @see [unknown]:0
* @route '/api/approvals/workflows/{approvalWorkflow}/deactivate'
*/
deactivate.url = (args: { approvalWorkflow: string | number } | [approvalWorkflow: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { approvalWorkflow: args }
    }

    if (Array.isArray(args)) {
        args = {
            approvalWorkflow: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        approvalWorkflow: args.approvalWorkflow,
    }

    return deactivate.definition.url
            .replace('{approvalWorkflow}', parsedArgs.approvalWorkflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::deactivate
* @see [unknown]:0
* @route '/api/approvals/workflows/{approvalWorkflow}/deactivate'
*/
deactivate.post = (args: { approvalWorkflow: string | number } | [approvalWorkflow: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: deactivate.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::destroy
* @see [unknown]:0
* @route '/api/approvals/workflows/{approvalWorkflow}'
*/
export const destroy = (args: { approvalWorkflow: string | number } | [approvalWorkflow: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/approvals/workflows/{approvalWorkflow}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::destroy
* @see [unknown]:0
* @route '/api/approvals/workflows/{approvalWorkflow}'
*/
destroy.url = (args: { approvalWorkflow: string | number } | [approvalWorkflow: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { approvalWorkflow: args }
    }

    if (Array.isArray(args)) {
        args = {
            approvalWorkflow: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        approvalWorkflow: args.approvalWorkflow,
    }

    return destroy.definition.url
            .replace('{approvalWorkflow}', parsedArgs.approvalWorkflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ApprovalWorkflowController::destroy
* @see [unknown]:0
* @route '/api/approvals/workflows/{approvalWorkflow}'
*/
destroy.delete = (args: { approvalWorkflow: string | number } | [approvalWorkflow: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

const ApprovalWorkflowController = { index, show, store, update, createVersion, activateVersion, deactivate, destroy }

export default ApprovalWorkflowController