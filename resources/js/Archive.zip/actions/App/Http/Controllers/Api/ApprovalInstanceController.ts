import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\ApprovalInstanceController::index
* @see [unknown]:0
* @route '/api/approvals/instances'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/approvals/instances',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ApprovalInstanceController::index
* @see [unknown]:0
* @route '/api/approvals/instances'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ApprovalInstanceController::index
* @see [unknown]:0
* @route '/api/approvals/instances'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ApprovalInstanceController::index
* @see [unknown]:0
* @route '/api/approvals/instances'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\ApprovalInstanceController::pendingForUser
* @see [unknown]:0
* @route '/api/approvals/instances/pending'
*/
export const pendingForUser = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pendingForUser.url(options),
    method: 'get',
})

pendingForUser.definition = {
    methods: ["get","head"],
    url: '/api/approvals/instances/pending',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ApprovalInstanceController::pendingForUser
* @see [unknown]:0
* @route '/api/approvals/instances/pending'
*/
pendingForUser.url = (options?: RouteQueryOptions) => {
    return pendingForUser.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ApprovalInstanceController::pendingForUser
* @see [unknown]:0
* @route '/api/approvals/instances/pending'
*/
pendingForUser.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pendingForUser.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ApprovalInstanceController::pendingForUser
* @see [unknown]:0
* @route '/api/approvals/instances/pending'
*/
pendingForUser.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pendingForUser.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\ApprovalInstanceController::show
* @see [unknown]:0
* @route '/api/approvals/instances/{approvalInstance}'
*/
export const show = (args: { approvalInstance: string | number } | [approvalInstance: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/approvals/instances/{approvalInstance}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ApprovalInstanceController::show
* @see [unknown]:0
* @route '/api/approvals/instances/{approvalInstance}'
*/
show.url = (args: { approvalInstance: string | number } | [approvalInstance: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { approvalInstance: args }
    }

    if (Array.isArray(args)) {
        args = {
            approvalInstance: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        approvalInstance: args.approvalInstance,
    }

    return show.definition.url
            .replace('{approvalInstance}', parsedArgs.approvalInstance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ApprovalInstanceController::show
* @see [unknown]:0
* @route '/api/approvals/instances/{approvalInstance}'
*/
show.get = (args: { approvalInstance: string | number } | [approvalInstance: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ApprovalInstanceController::show
* @see [unknown]:0
* @route '/api/approvals/instances/{approvalInstance}'
*/
show.head = (args: { approvalInstance: string | number } | [approvalInstance: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\ApprovalInstanceController::submit
* @see [unknown]:0
* @route '/api/approvals/instances/{approvalInstance}/submit'
*/
export const submit = (args: { approvalInstance: string | number } | [approvalInstance: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

submit.definition = {
    methods: ["post"],
    url: '/api/approvals/instances/{approvalInstance}/submit',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ApprovalInstanceController::submit
* @see [unknown]:0
* @route '/api/approvals/instances/{approvalInstance}/submit'
*/
submit.url = (args: { approvalInstance: string | number } | [approvalInstance: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { approvalInstance: args }
    }

    if (Array.isArray(args)) {
        args = {
            approvalInstance: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        approvalInstance: args.approvalInstance,
    }

    return submit.definition.url
            .replace('{approvalInstance}', parsedArgs.approvalInstance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ApprovalInstanceController::submit
* @see [unknown]:0
* @route '/api/approvals/instances/{approvalInstance}/submit'
*/
submit.post = (args: { approvalInstance: string | number } | [approvalInstance: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\ApprovalInstanceController::cancel
* @see [unknown]:0
* @route '/api/approvals/instances/{approvalInstance}/cancel'
*/
export const cancel = (args: { approvalInstance: string | number } | [approvalInstance: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

cancel.definition = {
    methods: ["post"],
    url: '/api/approvals/instances/{approvalInstance}/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ApprovalInstanceController::cancel
* @see [unknown]:0
* @route '/api/approvals/instances/{approvalInstance}/cancel'
*/
cancel.url = (args: { approvalInstance: string | number } | [approvalInstance: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { approvalInstance: args }
    }

    if (Array.isArray(args)) {
        args = {
            approvalInstance: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        approvalInstance: args.approvalInstance,
    }

    return cancel.definition.url
            .replace('{approvalInstance}', parsedArgs.approvalInstance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ApprovalInstanceController::cancel
* @see [unknown]:0
* @route '/api/approvals/instances/{approvalInstance}/cancel'
*/
cancel.post = (args: { approvalInstance: string | number } | [approvalInstance: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

const ApprovalInstanceController = { index, pendingForUser, show, submit, cancel }

export default ApprovalInstanceController