import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see routes/web.php:580
* @route '/app/site/{site}/settlements'
*/
export const index = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/app/site/{site}/settlements',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:580
* @route '/app/site/{site}/settlements'
*/
index.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return index.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:580
* @route '/app/site/{site}/settlements'
*/
index.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:580
* @route '/app/site/{site}/settlements'
*/
index.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

const settlements = {
    index: Object.assign(index, index),
}

export default settlements