import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\HistoricalReportController::exportMethod
* @see app/Http/Controllers/HistoricalReportController.php:258
* @route '/app/site/{site}/reports/historical/export'
*/
export const exportMethod = (args: { site: string | number | { site_code: string | number } } | [site: string | number | { site_code: string | number } ] | string | number | { site_code: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(args, options),
    method: 'get',
})

exportMethod.definition = {
    methods: ["get","head"],
    url: '/app/site/{site}/reports/historical/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HistoricalReportController::exportMethod
* @see app/Http/Controllers/HistoricalReportController.php:258
* @route '/app/site/{site}/reports/historical/export'
*/
exportMethod.url = (args: { site: string | number | { site_code: string | number } } | [site: string | number | { site_code: string | number } ] | string | number | { site_code: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return exportMethod.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HistoricalReportController::exportMethod
* @see app/Http/Controllers/HistoricalReportController.php:258
* @route '/app/site/{site}/reports/historical/export'
*/
exportMethod.get = (args: { site: string | number | { site_code: string | number } } | [site: string | number | { site_code: string | number } ] | string | number | { site_code: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\HistoricalReportController::exportMethod
* @see app/Http/Controllers/HistoricalReportController.php:258
* @route '/app/site/{site}/reports/historical/export'
*/
exportMethod.head = (args: { site: string | number | { site_code: string | number } } | [site: string | number | { site_code: string | number } ] | string | number | { site_code: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportMethod.url(args, options),
    method: 'head',
})

const historical = {
    export: Object.assign(exportMethod, exportMethod),
}

export default historical