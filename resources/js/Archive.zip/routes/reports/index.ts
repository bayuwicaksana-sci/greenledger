import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see routes/web.php:659
* @route '/app/site/{site}/reports/program-pnl'
*/
export const programPnl = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: programPnl.url(args, options),
    method: 'get',
})

programPnl.definition = {
    methods: ["get","head"],
    url: '/app/site/{site}/reports/program-pnl',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:659
* @route '/app/site/{site}/reports/program-pnl'
*/
programPnl.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return programPnl.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:659
* @route '/app/site/{site}/reports/program-pnl'
*/
programPnl.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: programPnl.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:659
* @route '/app/site/{site}/reports/program-pnl'
*/
programPnl.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: programPnl.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:667
* @route '/app/site/{site}/reports/budget'
*/
export const budget = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: budget.url(args, options),
    method: 'get',
})

budget.definition = {
    methods: ["get","head"],
    url: '/app/site/{site}/reports/budget',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:667
* @route '/app/site/{site}/reports/budget'
*/
budget.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return budget.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:667
* @route '/app/site/{site}/reports/budget'
*/
budget.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: budget.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:667
* @route '/app/site/{site}/reports/budget'
*/
budget.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: budget.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:675
* @route '/app/site/{site}/reports/revenue'
*/
export const revenue = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: revenue.url(args, options),
    method: 'get',
})

revenue.definition = {
    methods: ["get","head"],
    url: '/app/site/{site}/reports/revenue',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:675
* @route '/app/site/{site}/reports/revenue'
*/
revenue.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return revenue.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:675
* @route '/app/site/{site}/reports/revenue'
*/
revenue.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: revenue.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:675
* @route '/app/site/{site}/reports/revenue'
*/
revenue.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: revenue.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:683
* @route '/app/site/{site}/reports/expense'
*/
export const expense = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: expense.url(args, options),
    method: 'get',
})

expense.definition = {
    methods: ["get","head"],
    url: '/app/site/{site}/reports/expense',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:683
* @route '/app/site/{site}/reports/expense'
*/
expense.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return expense.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:683
* @route '/app/site/{site}/reports/expense'
*/
expense.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: expense.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:683
* @route '/app/site/{site}/reports/expense'
*/
expense.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: expense.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:691
* @route '/app/site/{site}/reports/transactions'
*/
export const transactions = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: transactions.url(args, options),
    method: 'get',
})

transactions.definition = {
    methods: ["get","head"],
    url: '/app/site/{site}/reports/transactions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:691
* @route '/app/site/{site}/reports/transactions'
*/
transactions.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return transactions.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:691
* @route '/app/site/{site}/reports/transactions'
*/
transactions.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: transactions.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:691
* @route '/app/site/{site}/reports/transactions'
*/
transactions.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: transactions.url(args, options),
    method: 'head',
})

const reports = {
    programPnl: Object.assign(programPnl, programPnl),
    budget: Object.assign(budget, budget),
    revenue: Object.assign(revenue, revenue),
    expense: Object.assign(expense, expense),
    transactions: Object.assign(transactions, transactions),
}

export default reports