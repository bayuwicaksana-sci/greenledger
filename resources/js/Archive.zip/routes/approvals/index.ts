import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\ApprovalInstanceController::index
* @see app/Http/Controllers/ApprovalInstanceController.php:20
* @route '/app/site/{site}/approvals'
*/
export const index = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/app/site/{site}/approvals',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ApprovalInstanceController::index
* @see app/Http/Controllers/ApprovalInstanceController.php:20
* @route '/app/site/{site}/approvals'
*/
index.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return index.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ApprovalInstanceController::index
* @see app/Http/Controllers/ApprovalInstanceController.php:20
* @route '/app/site/{site}/approvals'
*/
index.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ApprovalInstanceController::index
* @see app/Http/Controllers/ApprovalInstanceController.php:20
* @route '/app/site/{site}/approvals'
*/
index.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ApprovalInstanceController::show
* @see app/Http/Controllers/ApprovalInstanceController.php:42
* @route '/app/site/{site}/approvals/{approvalInstance}'
*/
export const show = (args: { site: string | { site_code: string }, approvalInstance: number | { id: number } } | [site: string | { site_code: string }, approvalInstance: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/app/site/{site}/approvals/{approvalInstance}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ApprovalInstanceController::show
* @see app/Http/Controllers/ApprovalInstanceController.php:42
* @route '/app/site/{site}/approvals/{approvalInstance}'
*/
show.url = (args: { site: string | { site_code: string }, approvalInstance: number | { id: number } } | [site: string | { site_code: string }, approvalInstance: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            site: args[0],
            approvalInstance: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
        approvalInstance: typeof args.approvalInstance === 'object'
        ? args.approvalInstance.id
        : args.approvalInstance,
    }

    return show.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace('{approvalInstance}', parsedArgs.approvalInstance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ApprovalInstanceController::show
* @see app/Http/Controllers/ApprovalInstanceController.php:42
* @route '/app/site/{site}/approvals/{approvalInstance}'
*/
show.get = (args: { site: string | { site_code: string }, approvalInstance: number | { id: number } } | [site: string | { site_code: string }, approvalInstance: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ApprovalInstanceController::show
* @see app/Http/Controllers/ApprovalInstanceController.php:42
* @route '/app/site/{site}/approvals/{approvalInstance}'
*/
show.head = (args: { site: string | { site_code: string }, approvalInstance: number | { id: number } } | [site: string | { site_code: string }, approvalInstance: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ApprovalInstanceController::action
* @see app/Http/Controllers/ApprovalInstanceController.php:69
* @route '/app/site/{site}/approvals/{approvalInstance}/action'
*/
export const action = (args: { site: string | { site_code: string }, approvalInstance: number | { id: number } } | [site: string | { site_code: string }, approvalInstance: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: action.url(args, options),
    method: 'post',
})

action.definition = {
    methods: ["post"],
    url: '/app/site/{site}/approvals/{approvalInstance}/action',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ApprovalInstanceController::action
* @see app/Http/Controllers/ApprovalInstanceController.php:69
* @route '/app/site/{site}/approvals/{approvalInstance}/action'
*/
action.url = (args: { site: string | { site_code: string }, approvalInstance: number | { id: number } } | [site: string | { site_code: string }, approvalInstance: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            site: args[0],
            approvalInstance: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
        approvalInstance: typeof args.approvalInstance === 'object'
        ? args.approvalInstance.id
        : args.approvalInstance,
    }

    return action.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace('{approvalInstance}', parsedArgs.approvalInstance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ApprovalInstanceController::action
* @see app/Http/Controllers/ApprovalInstanceController.php:69
* @route '/app/site/{site}/approvals/{approvalInstance}/action'
*/
action.post = (args: { site: string | { site_code: string }, approvalInstance: number | { id: number } } | [site: string | { site_code: string }, approvalInstance: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: action.url(args, options),
    method: 'post',
})

const approvals = {
    index: Object.assign(index, index),
    show: Object.assign(show, show),
    action: Object.assign(action, action),
}

export default approvals