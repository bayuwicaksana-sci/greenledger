import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see routes/web.php:478
* @route '/site/{site}/admin/users'
*/
export const users = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: users.url(args, options),
    method: 'get',
})

users.definition = {
    methods: ["get","head"],
    url: '/site/{site}/admin/users',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:478
* @route '/site/{site}/admin/users'
*/
users.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return users.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:478
* @route '/site/{site}/admin/users'
*/
users.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: users.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:478
* @route '/site/{site}/admin/users'
*/
users.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: users.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:478
* @route '/site/{site}/admin/users'
*/
const usersForm = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: users.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:478
* @route '/site/{site}/admin/users'
*/
usersForm.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: users.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:478
* @route '/site/{site}/admin/users'
*/
usersForm.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: users.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

users.form = usersForm

/**
* @see routes/web.php:488
* @route '/site/{site}/admin/roles'
*/
export const roles = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: roles.url(args, options),
    method: 'get',
})

roles.definition = {
    methods: ["get","head"],
    url: '/site/{site}/admin/roles',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:488
* @route '/site/{site}/admin/roles'
*/
roles.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return roles.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:488
* @route '/site/{site}/admin/roles'
*/
roles.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: roles.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:488
* @route '/site/{site}/admin/roles'
*/
roles.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: roles.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:488
* @route '/site/{site}/admin/roles'
*/
const rolesForm = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: roles.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:488
* @route '/site/{site}/admin/roles'
*/
rolesForm.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: roles.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:488
* @route '/site/{site}/admin/roles'
*/
rolesForm.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: roles.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

roles.form = rolesForm

/**
* @see routes/web.php:496
* @route '/site/{site}/admin/logs'
*/
export const logs = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: logs.url(args, options),
    method: 'get',
})

logs.definition = {
    methods: ["get","head"],
    url: '/site/{site}/admin/logs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:496
* @route '/site/{site}/admin/logs'
*/
logs.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return logs.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:496
* @route '/site/{site}/admin/logs'
*/
logs.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: logs.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:496
* @route '/site/{site}/admin/logs'
*/
logs.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: logs.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:496
* @route '/site/{site}/admin/logs'
*/
const logsForm = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: logs.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:496
* @route '/site/{site}/admin/logs'
*/
logsForm.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: logs.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:496
* @route '/site/{site}/admin/logs'
*/
logsForm.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: logs.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

logs.form = logsForm

/**
* @see routes/web.php:504
* @route '/site/{site}/admin/health'
*/
export const health = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: health.url(args, options),
    method: 'get',
})

health.definition = {
    methods: ["get","head"],
    url: '/site/{site}/admin/health',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:504
* @route '/site/{site}/admin/health'
*/
health.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return health.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:504
* @route '/site/{site}/admin/health'
*/
health.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: health.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:504
* @route '/site/{site}/admin/health'
*/
health.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: health.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:504
* @route '/site/{site}/admin/health'
*/
const healthForm = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: health.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:504
* @route '/site/{site}/admin/health'
*/
healthForm.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: health.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:504
* @route '/site/{site}/admin/health'
*/
healthForm.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: health.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

health.form = healthForm

const admin = {
    users: Object.assign(users, users),
    roles: Object.assign(roles, roles),
    logs: Object.assign(logs, logs),
    health: Object.assign(health, health),
}

export default admin