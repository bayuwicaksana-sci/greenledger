import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../wayfinder'
import approvalWorkflows from './approval-workflows'
/**
* @see routes/web.php:319
* @route '/app/admin/users'
*/
export const users = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: users.url(options),
    method: 'get',
})

users.definition = {
    methods: ["get","head"],
    url: '/app/admin/users',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:319
* @route '/app/admin/users'
*/
users.url = (options?: RouteQueryOptions) => {
    return users.definition.url + queryParams(options)
}

/**
* @see routes/web.php:319
* @route '/app/admin/users'
*/
users.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: users.url(options),
    method: 'get',
})

/**
* @see routes/web.php:319
* @route '/app/admin/users'
*/
users.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: users.url(options),
    method: 'head',
})

/**
* @see routes/web.php:325
* @route '/app/admin/roles'
*/
export const roles = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: roles.url(options),
    method: 'get',
})

roles.definition = {
    methods: ["get","head"],
    url: '/app/admin/roles',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:325
* @route '/app/admin/roles'
*/
roles.url = (options?: RouteQueryOptions) => {
    return roles.definition.url + queryParams(options)
}

/**
* @see routes/web.php:325
* @route '/app/admin/roles'
*/
roles.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: roles.url(options),
    method: 'get',
})

/**
* @see routes/web.php:325
* @route '/app/admin/roles'
*/
roles.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: roles.url(options),
    method: 'head',
})

/**
* @see routes/web.php:333
* @route '/app/admin/logs'
*/
export const logs = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: logs.url(options),
    method: 'get',
})

logs.definition = {
    methods: ["get","head"],
    url: '/app/admin/logs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:333
* @route '/app/admin/logs'
*/
logs.url = (options?: RouteQueryOptions) => {
    return logs.definition.url + queryParams(options)
}

/**
* @see routes/web.php:333
* @route '/app/admin/logs'
*/
logs.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: logs.url(options),
    method: 'get',
})

/**
* @see routes/web.php:333
* @route '/app/admin/logs'
*/
logs.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: logs.url(options),
    method: 'head',
})

/**
* @see routes/web.php:339
* @route '/app/admin/health'
*/
export const health = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: health.url(options),
    method: 'get',
})

health.definition = {
    methods: ["get","head"],
    url: '/app/admin/health',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:339
* @route '/app/admin/health'
*/
health.url = (options?: RouteQueryOptions) => {
    return health.definition.url + queryParams(options)
}

/**
* @see routes/web.php:339
* @route '/app/admin/health'
*/
health.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: health.url(options),
    method: 'get',
})

/**
* @see routes/web.php:339
* @route '/app/admin/health'
*/
health.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: health.url(options),
    method: 'head',
})

const admin = {
    users: Object.assign(users, users),
    roles: Object.assign(roles, roles),
    logs: Object.assign(logs, logs),
    health: Object.assign(health, health),
    approvalWorkflows: Object.assign(approvalWorkflows, approvalWorkflows),
}

export default admin