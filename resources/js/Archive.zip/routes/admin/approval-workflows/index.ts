import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\ApprovalWorkflowController::index
* @see app/Http/Controllers/ApprovalWorkflowController.php:29
* @route '/app/admin/approval-workflows'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/app/admin/approval-workflows',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::index
* @see app/Http/Controllers/ApprovalWorkflowController.php:29
* @route '/app/admin/approval-workflows'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::index
* @see app/Http/Controllers/ApprovalWorkflowController.php:29
* @route '/app/admin/approval-workflows'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::index
* @see app/Http/Controllers/ApprovalWorkflowController.php:29
* @route '/app/admin/approval-workflows'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::create
* @see app/Http/Controllers/ApprovalWorkflowController.php:60
* @route '/app/admin/approval-workflows/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/app/admin/approval-workflows/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::create
* @see app/Http/Controllers/ApprovalWorkflowController.php:60
* @route '/app/admin/approval-workflows/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::create
* @see app/Http/Controllers/ApprovalWorkflowController.php:60
* @route '/app/admin/approval-workflows/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::create
* @see app/Http/Controllers/ApprovalWorkflowController.php:60
* @route '/app/admin/approval-workflows/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::store
* @see app/Http/Controllers/ApprovalWorkflowController.php:87
* @route '/app/admin/approval-workflows'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/app/admin/approval-workflows',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::store
* @see app/Http/Controllers/ApprovalWorkflowController.php:87
* @route '/app/admin/approval-workflows'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::store
* @see app/Http/Controllers/ApprovalWorkflowController.php:87
* @route '/app/admin/approval-workflows'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::edit
* @see app/Http/Controllers/ApprovalWorkflowController.php:124
* @route '/app/admin/approval-workflows/{approvalWorkflow}/edit'
*/
export const edit = (args: { approvalWorkflow: number | { id: number } } | [approvalWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/app/admin/approval-workflows/{approvalWorkflow}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::edit
* @see app/Http/Controllers/ApprovalWorkflowController.php:124
* @route '/app/admin/approval-workflows/{approvalWorkflow}/edit'
*/
edit.url = (args: { approvalWorkflow: number | { id: number } } | [approvalWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { approvalWorkflow: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { approvalWorkflow: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            approvalWorkflow: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        approvalWorkflow: typeof args.approvalWorkflow === 'object'
        ? args.approvalWorkflow.id
        : args.approvalWorkflow,
    }

    return edit.definition.url
            .replace('{approvalWorkflow}', parsedArgs.approvalWorkflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::edit
* @see app/Http/Controllers/ApprovalWorkflowController.php:124
* @route '/app/admin/approval-workflows/{approvalWorkflow}/edit'
*/
edit.get = (args: { approvalWorkflow: number | { id: number } } | [approvalWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::edit
* @see app/Http/Controllers/ApprovalWorkflowController.php:124
* @route '/app/admin/approval-workflows/{approvalWorkflow}/edit'
*/
edit.head = (args: { approvalWorkflow: number | { id: number } } | [approvalWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::update
* @see app/Http/Controllers/ApprovalWorkflowController.php:149
* @route '/app/admin/approval-workflows/{approvalWorkflow}'
*/
export const update = (args: { approvalWorkflow: number | { id: number } } | [approvalWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/app/admin/approval-workflows/{approvalWorkflow}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::update
* @see app/Http/Controllers/ApprovalWorkflowController.php:149
* @route '/app/admin/approval-workflows/{approvalWorkflow}'
*/
update.url = (args: { approvalWorkflow: number | { id: number } } | [approvalWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { approvalWorkflow: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { approvalWorkflow: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            approvalWorkflow: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        approvalWorkflow: typeof args.approvalWorkflow === 'object'
        ? args.approvalWorkflow.id
        : args.approvalWorkflow,
    }

    return update.definition.url
            .replace('{approvalWorkflow}', parsedArgs.approvalWorkflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::update
* @see app/Http/Controllers/ApprovalWorkflowController.php:149
* @route '/app/admin/approval-workflows/{approvalWorkflow}'
*/
update.put = (args: { approvalWorkflow: number | { id: number } } | [approvalWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::destroy
* @see app/Http/Controllers/ApprovalWorkflowController.php:193
* @route '/app/admin/approval-workflows/{approvalWorkflow}'
*/
export const destroy = (args: { approvalWorkflow: number | { id: number } } | [approvalWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/app/admin/approval-workflows/{approvalWorkflow}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::destroy
* @see app/Http/Controllers/ApprovalWorkflowController.php:193
* @route '/app/admin/approval-workflows/{approvalWorkflow}'
*/
destroy.url = (args: { approvalWorkflow: number | { id: number } } | [approvalWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { approvalWorkflow: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { approvalWorkflow: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            approvalWorkflow: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        approvalWorkflow: typeof args.approvalWorkflow === 'object'
        ? args.approvalWorkflow.id
        : args.approvalWorkflow,
    }

    return destroy.definition.url
            .replace('{approvalWorkflow}', parsedArgs.approvalWorkflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::destroy
* @see app/Http/Controllers/ApprovalWorkflowController.php:193
* @route '/app/admin/approval-workflows/{approvalWorkflow}'
*/
destroy.delete = (args: { approvalWorkflow: number | { id: number } } | [approvalWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::duplicate
* @see app/Http/Controllers/ApprovalWorkflowController.php:208
* @route '/app/admin/approval-workflows/{approvalWorkflow}/duplicate'
*/
export const duplicate = (args: { approvalWorkflow: number | { id: number } } | [approvalWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: duplicate.url(args, options),
    method: 'post',
})

duplicate.definition = {
    methods: ["post"],
    url: '/app/admin/approval-workflows/{approvalWorkflow}/duplicate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::duplicate
* @see app/Http/Controllers/ApprovalWorkflowController.php:208
* @route '/app/admin/approval-workflows/{approvalWorkflow}/duplicate'
*/
duplicate.url = (args: { approvalWorkflow: number | { id: number } } | [approvalWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { approvalWorkflow: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { approvalWorkflow: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            approvalWorkflow: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        approvalWorkflow: typeof args.approvalWorkflow === 'object'
        ? args.approvalWorkflow.id
        : args.approvalWorkflow,
    }

    return duplicate.definition.url
            .replace('{approvalWorkflow}', parsedArgs.approvalWorkflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::duplicate
* @see app/Http/Controllers/ApprovalWorkflowController.php:208
* @route '/app/admin/approval-workflows/{approvalWorkflow}/duplicate'
*/
duplicate.post = (args: { approvalWorkflow: number | { id: number } } | [approvalWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: duplicate.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::setActive
* @see app/Http/Controllers/ApprovalWorkflowController.php:231
* @route '/app/admin/approval-workflows/{approvalWorkflow}/set-active'
*/
export const setActive = (args: { approvalWorkflow: number | { id: number } } | [approvalWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: setActive.url(args, options),
    method: 'post',
})

setActive.definition = {
    methods: ["post"],
    url: '/app/admin/approval-workflows/{approvalWorkflow}/set-active',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::setActive
* @see app/Http/Controllers/ApprovalWorkflowController.php:231
* @route '/app/admin/approval-workflows/{approvalWorkflow}/set-active'
*/
setActive.url = (args: { approvalWorkflow: number | { id: number } } | [approvalWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { approvalWorkflow: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { approvalWorkflow: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            approvalWorkflow: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        approvalWorkflow: typeof args.approvalWorkflow === 'object'
        ? args.approvalWorkflow.id
        : args.approvalWorkflow,
    }

    return setActive.definition.url
            .replace('{approvalWorkflow}', parsedArgs.approvalWorkflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::setActive
* @see app/Http/Controllers/ApprovalWorkflowController.php:231
* @route '/app/admin/approval-workflows/{approvalWorkflow}/set-active'
*/
setActive.post = (args: { approvalWorkflow: number | { id: number } } | [approvalWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: setActive.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::deactivate
* @see app/Http/Controllers/ApprovalWorkflowController.php:246
* @route '/app/admin/approval-workflows/{approvalWorkflow}/deactivate'
*/
export const deactivate = (args: { approvalWorkflow: number | { id: number } } | [approvalWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: deactivate.url(args, options),
    method: 'post',
})

deactivate.definition = {
    methods: ["post"],
    url: '/app/admin/approval-workflows/{approvalWorkflow}/deactivate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::deactivate
* @see app/Http/Controllers/ApprovalWorkflowController.php:246
* @route '/app/admin/approval-workflows/{approvalWorkflow}/deactivate'
*/
deactivate.url = (args: { approvalWorkflow: number | { id: number } } | [approvalWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { approvalWorkflow: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { approvalWorkflow: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            approvalWorkflow: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        approvalWorkflow: typeof args.approvalWorkflow === 'object'
        ? args.approvalWorkflow.id
        : args.approvalWorkflow,
    }

    return deactivate.definition.url
            .replace('{approvalWorkflow}', parsedArgs.approvalWorkflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::deactivate
* @see app/Http/Controllers/ApprovalWorkflowController.php:246
* @route '/app/admin/approval-workflows/{approvalWorkflow}/deactivate'
*/
deactivate.post = (args: { approvalWorkflow: number | { id: number } } | [approvalWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: deactivate.url(args, options),
    method: 'post',
})

const approvalWorkflows = {
    index: Object.assign(index, index),
    create: Object.assign(create, create),
    store: Object.assign(store, store),
    edit: Object.assign(edit, edit),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
    duplicate: Object.assign(duplicate, duplicate),
    setActive: Object.assign(setActive, setActive),
    deactivate: Object.assign(deactivate, deactivate),
}

export default approvalWorkflows