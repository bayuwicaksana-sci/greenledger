import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CoaAccountTemplateController::index
* @see app/Http/Controllers/CoaAccountTemplateController.php:18
* @route '/app/config/coa/templates'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/app/config/coa/templates',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CoaAccountTemplateController::index
* @see app/Http/Controllers/CoaAccountTemplateController.php:18
* @route '/app/config/coa/templates'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CoaAccountTemplateController::index
* @see app/Http/Controllers/CoaAccountTemplateController.php:18
* @route '/app/config/coa/templates'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\CoaAccountTemplateController::index
* @see app/Http/Controllers/CoaAccountTemplateController.php:18
* @route '/app/config/coa/templates'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\CoaAccountTemplateController::apply
* @see app/Http/Controllers/CoaAccountTemplateController.php:51
* @route '/app/config/coa/templates/apply'
*/
export const apply = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: apply.url(options),
    method: 'post',
})

apply.definition = {
    methods: ["post"],
    url: '/app/config/coa/templates/apply',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CoaAccountTemplateController::apply
* @see app/Http/Controllers/CoaAccountTemplateController.php:51
* @route '/app/config/coa/templates/apply'
*/
apply.url = (options?: RouteQueryOptions) => {
    return apply.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CoaAccountTemplateController::apply
* @see app/Http/Controllers/CoaAccountTemplateController.php:51
* @route '/app/config/coa/templates/apply'
*/
apply.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: apply.url(options),
    method: 'post',
})

const templates = {
    index: Object.assign(index, index),
    apply: Object.assign(apply, apply),
}

export default templates