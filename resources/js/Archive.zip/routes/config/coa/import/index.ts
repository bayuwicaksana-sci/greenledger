import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CoaAccountImportController::validate
* @see app/Http/Controllers/CoaAccountImportController.php:18
* @route '/app/config/coa/import/validate'
*/
export const validate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: validate.url(options),
    method: 'post',
})

validate.definition = {
    methods: ["post"],
    url: '/app/config/coa/import/validate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CoaAccountImportController::validate
* @see app/Http/Controllers/CoaAccountImportController.php:18
* @route '/app/config/coa/import/validate'
*/
validate.url = (options?: RouteQueryOptions) => {
    return validate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CoaAccountImportController::validate
* @see app/Http/Controllers/CoaAccountImportController.php:18
* @route '/app/config/coa/import/validate'
*/
validate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: validate.url(options),
    method: 'post',
})

