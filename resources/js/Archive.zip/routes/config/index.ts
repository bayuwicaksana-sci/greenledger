import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see routes/web.php:441
* @route '/site/{site}/config/coa'
*/
export const coa = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: coa.url(args, options),
    method: 'get',
})

coa.definition = {
    methods: ["get","head"],
    url: '/site/{site}/config/coa',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:441
* @route '/site/{site}/config/coa'
*/
coa.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return coa.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:441
* @route '/site/{site}/config/coa'
*/
coa.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: coa.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:441
* @route '/site/{site}/config/coa'
*/
coa.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: coa.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:441
* @route '/site/{site}/config/coa'
*/
const coaForm = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: coa.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:441
* @route '/site/{site}/config/coa'
*/
coaForm.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: coa.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:441
* @route '/site/{site}/config/coa'
*/
coaForm.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: coa.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

coa.form = coaForm

/**
* @see routes/web.php:449
* @route '/site/{site}/config/sites'
*/
export const sites = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sites.url(args, options),
    method: 'get',
})

sites.definition = {
    methods: ["get","head"],
    url: '/site/{site}/config/sites',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:449
* @route '/site/{site}/config/sites'
*/
sites.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return sites.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:449
* @route '/site/{site}/config/sites'
*/
sites.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sites.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:449
* @route '/site/{site}/config/sites'
*/
sites.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sites.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:449
* @route '/site/{site}/config/sites'
*/
const sitesForm = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: sites.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:449
* @route '/site/{site}/config/sites'
*/
sitesForm.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: sites.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:449
* @route '/site/{site}/config/sites'
*/
sitesForm.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: sites.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

sites.form = sitesForm

/**
* @see routes/web.php:457
* @route '/site/{site}/config/buyers-clients'
*/
export const buyersClients = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: buyersClients.url(args, options),
    method: 'get',
})

buyersClients.definition = {
    methods: ["get","head"],
    url: '/site/{site}/config/buyers-clients',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:457
* @route '/site/{site}/config/buyers-clients'
*/
buyersClients.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return buyersClients.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:457
* @route '/site/{site}/config/buyers-clients'
*/
buyersClients.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: buyersClients.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:457
* @route '/site/{site}/config/buyers-clients'
*/
buyersClients.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: buyersClients.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:457
* @route '/site/{site}/config/buyers-clients'
*/
const buyersClientsForm = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: buyersClients.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:457
* @route '/site/{site}/config/buyers-clients'
*/
buyersClientsForm.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: buyersClients.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:457
* @route '/site/{site}/config/buyers-clients'
*/
buyersClientsForm.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: buyersClients.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

buyersClients.form = buyersClientsForm

/**
* @see routes/web.php:465
* @route '/site/{site}/config/settings'
*/
export const settings = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: settings.url(args, options),
    method: 'get',
})

settings.definition = {
    methods: ["get","head"],
    url: '/site/{site}/config/settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:465
* @route '/site/{site}/config/settings'
*/
settings.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return settings.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:465
* @route '/site/{site}/config/settings'
*/
settings.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: settings.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:465
* @route '/site/{site}/config/settings'
*/
settings.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: settings.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:465
* @route '/site/{site}/config/settings'
*/
const settingsForm = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: settings.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:465
* @route '/site/{site}/config/settings'
*/
settingsForm.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: settings.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:465
* @route '/site/{site}/config/settings'
*/
settingsForm.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: settings.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

settings.form = settingsForm

const config = {
    coa: Object.assign(coa, coa),
    sites: Object.assign(sites, sites),
    buyersClients: Object.assign(buyersClients, buyersClients),
    settings: Object.assign(settings, settings),
}

export default config