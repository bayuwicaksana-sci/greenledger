import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see routes/web.php:512
* @route '/app/site/{site}/payment-requests'
*/
export const index = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/app/site/{site}/payment-requests',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:512
* @route '/app/site/{site}/payment-requests'
*/
index.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return index.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:512
* @route '/app/site/{site}/payment-requests'
*/
index.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:512
* @route '/app/site/{site}/payment-requests'
*/
index.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:522
* @route '/app/site/{site}/payment-requests/my'
*/
export const my = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: my.url(args, options),
    method: 'get',
})

my.definition = {
    methods: ["get","head"],
    url: '/app/site/{site}/payment-requests/my',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:522
* @route '/app/site/{site}/payment-requests/my'
*/
my.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return my.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:522
* @route '/app/site/{site}/payment-requests/my'
*/
my.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: my.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:522
* @route '/app/site/{site}/payment-requests/my'
*/
my.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: my.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:532
* @route '/app/site/{site}/payment-requests/create'
*/
export const create = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/app/site/{site}/payment-requests/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:532
* @route '/app/site/{site}/payment-requests/create'
*/
create.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return create.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:532
* @route '/app/site/{site}/payment-requests/create'
*/
create.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:532
* @route '/app/site/{site}/payment-requests/create'
*/
create.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:542
* @route '/app/site/{site}/payment-requests/approvals'
*/
export const approvals = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: approvals.url(args, options),
    method: 'get',
})

approvals.definition = {
    methods: ["get","head"],
    url: '/app/site/{site}/payment-requests/approvals',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:542
* @route '/app/site/{site}/payment-requests/approvals'
*/
approvals.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return approvals.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:542
* @route '/app/site/{site}/payment-requests/approvals'
*/
approvals.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: approvals.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:542
* @route '/app/site/{site}/payment-requests/approvals'
*/
approvals.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: approvals.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:554
* @route '/app/site/{site}/payment-requests/queue'
*/
export const queue = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: queue.url(args, options),
    method: 'get',
})

queue.definition = {
    methods: ["get","head"],
    url: '/app/site/{site}/payment-requests/queue',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:554
* @route '/app/site/{site}/payment-requests/queue'
*/
queue.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return queue.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:554
* @route '/app/site/{site}/payment-requests/queue'
*/
queue.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: queue.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:554
* @route '/app/site/{site}/payment-requests/queue'
*/
queue.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: queue.url(args, options),
    method: 'head',
})

const paymentRequests = {
    index: Object.assign(index, index),
    my: Object.assign(my, my),
    create: Object.assign(create, create),
    approvals: Object.assign(approvals, approvals),
    queue: Object.assign(queue, queue),
}

export default paymentRequests