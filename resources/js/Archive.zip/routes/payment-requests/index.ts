import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see routes/web.php:215
* @route '/site/{site}/payment-requests'
*/
export const index = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/site/{site}/payment-requests',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:215
* @route '/site/{site}/payment-requests'
*/
index.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return index.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:215
* @route '/site/{site}/payment-requests'
*/
index.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:215
* @route '/site/{site}/payment-requests'
*/
index.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:215
* @route '/site/{site}/payment-requests'
*/
const indexForm = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:215
* @route '/site/{site}/payment-requests'
*/
indexForm.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:215
* @route '/site/{site}/payment-requests'
*/
indexForm.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see routes/web.php:225
* @route '/site/{site}/payment-requests/my'
*/
export const my = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: my.url(args, options),
    method: 'get',
})

my.definition = {
    methods: ["get","head"],
    url: '/site/{site}/payment-requests/my',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:225
* @route '/site/{site}/payment-requests/my'
*/
my.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return my.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:225
* @route '/site/{site}/payment-requests/my'
*/
my.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: my.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:225
* @route '/site/{site}/payment-requests/my'
*/
my.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: my.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:225
* @route '/site/{site}/payment-requests/my'
*/
const myForm = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: my.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:225
* @route '/site/{site}/payment-requests/my'
*/
myForm.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: my.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:225
* @route '/site/{site}/payment-requests/my'
*/
myForm.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: my.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

my.form = myForm

/**
* @see routes/web.php:233
* @route '/site/{site}/payment-requests/create'
*/
export const create = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/site/{site}/payment-requests/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:233
* @route '/site/{site}/payment-requests/create'
*/
create.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return create.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:233
* @route '/site/{site}/payment-requests/create'
*/
create.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:233
* @route '/site/{site}/payment-requests/create'
*/
create.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:233
* @route '/site/{site}/payment-requests/create'
*/
const createForm = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:233
* @route '/site/{site}/payment-requests/create'
*/
createForm.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:233
* @route '/site/{site}/payment-requests/create'
*/
createForm.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see routes/web.php:243
* @route '/site/{site}/payment-requests/approvals'
*/
export const approvals = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: approvals.url(args, options),
    method: 'get',
})

approvals.definition = {
    methods: ["get","head"],
    url: '/site/{site}/payment-requests/approvals',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:243
* @route '/site/{site}/payment-requests/approvals'
*/
approvals.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return approvals.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:243
* @route '/site/{site}/payment-requests/approvals'
*/
approvals.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: approvals.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:243
* @route '/site/{site}/payment-requests/approvals'
*/
approvals.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: approvals.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:243
* @route '/site/{site}/payment-requests/approvals'
*/
const approvalsForm = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: approvals.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:243
* @route '/site/{site}/payment-requests/approvals'
*/
approvalsForm.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: approvals.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:243
* @route '/site/{site}/payment-requests/approvals'
*/
approvalsForm.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: approvals.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

approvals.form = approvalsForm

/**
* @see routes/web.php:251
* @route '/site/{site}/payment-requests/queue'
*/
export const queue = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: queue.url(args, options),
    method: 'get',
})

queue.definition = {
    methods: ["get","head"],
    url: '/site/{site}/payment-requests/queue',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:251
* @route '/site/{site}/payment-requests/queue'
*/
queue.url = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'site_code' in args) {
        args = { site: args.site_code }
    }

    if (Array.isArray(args)) {
        args = {
            site: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        site: typeof args.site === 'object'
        ? args.site.site_code
        : args.site,
    }

    return queue.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:251
* @route '/site/{site}/payment-requests/queue'
*/
queue.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: queue.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:251
* @route '/site/{site}/payment-requests/queue'
*/
queue.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: queue.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:251
* @route '/site/{site}/payment-requests/queue'
*/
const queueForm = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: queue.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:251
* @route '/site/{site}/payment-requests/queue'
*/
queueForm.get = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: queue.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:251
* @route '/site/{site}/payment-requests/queue'
*/
queueForm.head = (args: { site: string | { site_code: string } } | [site: string | { site_code: string } ] | string | { site_code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: queue.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

queue.form = queueForm

const paymentRequests = {
    index: Object.assign(index, index),
    my: Object.assign(my, my),
    create: Object.assign(create, create),
    approvals: Object.assign(approvals, approvals),
    queue: Object.assign(queue, queue),
}

export default paymentRequests