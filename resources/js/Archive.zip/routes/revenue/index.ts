import harvest from './harvest'
import testing from './testing'

const revenue = {
    harvest: Object.assign(harvest, harvest),
    testing: Object.assign(testing, testing),
}

export default revenue